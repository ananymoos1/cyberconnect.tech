This simple BAT script automatically replaces the new Roblox death sound, with the original "OOF" sound.
I have made this since in my opinion, the new sound is horrible.

How to use:
Step 1: Open the BAT file in a text editor (Preferably Notepad or VS Code)
Step 2: Replace the "USERNAME" text with your currently logged in windows account's USERNAME
Step 3: Run the BAT file
Enjoy!

If you would like to support my other projects, visit https://ananymoos-tech.cf for more info.